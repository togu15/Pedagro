const sequelize = require('../config/database');
const Classe = require('./Classe');
const ThematiqueGenerale = require('./ThematiqueGenerale');
const ThematiqueParticuliere = require('./ThematiqueParticuliere');
const Fiche = require('./Fiche');

// Relations
Fiche.belongsToMany(Classe, { through: 'FicheClasse' });
Classe.belongsToMany(Fiche, { through: 'FicheClasse' });

Fiche.belongsToMany(ThematiqueGenerale, { through: 'FicheThematiqueGenerale' });
ThematiqueGenerale.belongsToMany(Fiche, { through: 'FicheThematiqueGenerale' });

Fiche.belongsToMany(ThematiqueParticuliere, { through: 'FicheThematiqueParticuliere' });
ThematiqueParticuliere.belongsToMany(Fiche, { through: 'FicheThematiqueParticuliere' });

module.exports = {
  Classe,
  ThematiqueGenerale,
  ThematiqueParticuliere,
  Fiche
};
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const ThematiqueGenerale = sequelize.define('ThematiqueGenerale', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  nom: {
    type: DataTypes.STRING,
    unique: true,
    allowNull: false
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: true
  }
}, {
  timestamps: false
});

module.exports = ThematiqueGenerale;
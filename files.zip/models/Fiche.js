const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Fiche = sequelize.define('Fiche', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  titre: {
    type: DataTypes.STRING,
    allowNull: false
  },
  contenu: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  fichierPath: {
    type: DataTypes.STRING,
    allowNull: true
  },
  dateCreation: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  },
  dateModification: {
    type: DataTypes.DATE,
    allowNull: true
  }
}, {
  timestamps: false
});

module.exports = Fiche;
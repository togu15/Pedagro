const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const ThematiqueGenerale = require('./ThematiqueGenerale');

const ThematiqueParticuliere = sequelize.define('ThematiqueParticuliere', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  nom: {
    type: DataTypes.STRING,
    allowNull: false
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  thematiqueGeneraleId: {
    type: DataTypes.INTEGER,
    references: {
      model: ThematiqueGenerale,
      key: 'id'
    }
  }
}, {
  timestamps: false
});

module.exports = ThematiqueParticuliere;
# Fiches Pédagogiques Agricoles

## Installation

1. Clonez le dépôt:
   ```bash
   git clone <https://github.com/togu15/Pedagro>
   cd fiches-pedagogiques-agricoles
   ```

2. Installez les dépendances:
   ```bash
   npm install
   ```

3. Configurez les variables d'environnement:
   - Créez un fichier `.env` à la racine du projet et ajoutez:
     ```env
     SESSION_SECRET=your_session_secret
     ```

4. Initialisez la base de données:
   ```bash
   npm run seed
   ```

5. Lancer l'application en mode développement:
   ```bash
   npm run dev
   ```

## Structure du projet

- `app.js`: Point d'entrée de l'application
- `config/`: Configuration de la base de données
- `controllers/`: Contrôleurs pour les différentes routes
- `models/`: Modèles de données Sequelize
- `routes/`: Définition des routes de l'application
- `views/`: Vues EJS pour le rendu côté serveur
- `public/`: Fichiers statiques (CSS, JS, images, PDF)

## Fonctionnalités

- **Interface utilisateur principale**: Affichage et filtrage des fiches pédagogiques
- **Interface d'administration**: Gestion des fiches, classes et thématiques
- **API**: Routes pour le filtrage dynamique et la gestion des entités

## Guide d'utilisation

### Interface utilisateur

1. Accédez à la page d'accueil pour voir la liste des fiches.
2. Utilisez les filtres pour affiner les résultats.
3. Cliquez sur une fiche pour voir les détails.

### Interface d'administration

1. Accédez à `/admin` pour gérer les fiches.
2. Utilisez les formulaires pour ajouter, modifier ou supprimer des fiches, classes et thématiques.

## Captures d'écran

### Page d'accueil
![Page d'accueil](./public/images/home.png)

### Interface d'administration
![Administration](./public/images/admin.png)
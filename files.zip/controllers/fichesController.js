const { Fiche, Classe, ThematiqueGenerale, ThematiqueParticuliere } = require('../models/relations');

exports.getFiches = async (req, res) => {
  try {
    const fiches = await Fiche.findAll();
    res.render('fiches/index', { fiches });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server Error');
  }
};

exports.getFiche = async (req, res) => {
  try {
    const fiche = await Fiche.findByPk(req.params.id);
    res.render('fiches/show', { fiche });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server Error');
  }
};

// Other CRUD operations for fiche
const express = require('express');
const router = express.Router();
const fichesController = require('../controllers/fichesController');

router.get('/', fichesController.getFiches);
router.get('/fiches/:id', fichesController.getFiche);

module.exports = router;
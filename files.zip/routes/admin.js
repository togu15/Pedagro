const express = require('express');
const router = express.Router();

// Add admin routes here

module.exports = router;
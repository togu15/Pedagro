const express = require('express');
const router = express.Router();

// Add API routes here

module.exports = router;
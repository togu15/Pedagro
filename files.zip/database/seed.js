const sequelize = require('../config/database');
const { Classe, ThematiqueGenerale, ThematiqueParticuliere, Fiche } = require('../models/relations');

const seedDatabase = async () => {
  await sequelize.sync({ force: true });

  const classes = await Classe.bulkCreate([
    { nom: 'CAPA', description: 'Certificat d\'Aptitude Professionnelle Agricole' },
    { nom: 'CS', description: 'Certificat de Spécialisation' },
    { nom: 'BPREA', description: 'Brevet Professionnel de Responsable d’Exploitation Agricole' },
  ]);

  const thematiquesGenerales = await ThematiqueGenerale.bulkCreate([
    { nom: 'Reproduction', description: 'Thématiques sur la reproduction animale' },
    { nom: 'Alimentation', description: "Thématiques sur l'alimentation des animaux" },
    // More thematiquesGenerales
  ]);

  const thematiquesParticulieres = await ThematiqueParticuliere.bulkCreate([
    { nom: 'Cycle œstral', thematiqueGeneraleId: thematiquesGenerales[0].id },
    { nom: 'Ration des vaches laitières', thematiqueGeneraleId: thematiquesGenerales[1].id },
    // More thematiquesParticulieres
  ]);

  const fiches = await Fiche.bulkCreate([
    { titre: 'Fiche 1', contenu: '<p>Contenu de la fiche 1</p>', fichierPath: null, dateCreation: new Date() },
    { titre: 'Fiche 2', contenu: '<p>Contenu de la fiche 2</p>', fichierPath: null, dateCreation: new Date() },
    // More fiches
  ]);

  console.log('Database seeded');
};

seedDatabase();